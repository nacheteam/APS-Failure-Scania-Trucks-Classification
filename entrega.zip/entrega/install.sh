#!/bin/bash

pip install -U imbalanced-learn

